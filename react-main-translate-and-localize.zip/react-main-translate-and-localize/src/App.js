// import logo from "./logo.svg";
import { Fragment } from "react";
import "./App.css";
import Header from "./components/Header";
import Hero from "./components/Hero";

function App() {
  return (
    <Fragment>
      <Header></Header>
      <Hero></Hero>
    </Fragment>
  );
}

export default App;
