import '../App.css';

const Hero = () => {
    return(
        <section id="hero" class="d-flex justify-cntent-center align-items-center">
            {/* // <!-- ======= Hero Section ======= --> */}
          <div id="heroCarousel" class="container carousel carousel-fade" data-bs-ride="carousel" data-bs-interval="5000">
      
            {/* <!-- Slide 1 --> */}
            <div class="carousel-item active">
              <div class="carousel-container">
                <h2 class="animate__animated animate__fadeInDown">Welcome to <span>TRANSLATEnLOCALIZE</span></h2>
                <p class="animate__animated animate__fadeInUp">
                  <div class="features-new animate__animated animate__fadeInUp">
                    <ul>
                  <li><i class="bi bi-check"></i> Up to 25 of the world&#39;s most widely spoken languages</li>
                  <li><i class="bi bi-check"></i> Includes: Translation, Dubbing, Subtitles, Localization,
                    Promotion And Partnership</li>
                  <li><i class="bi bi-check"></i> There will be no further investment on your part</li></ul></div>
      
                  </p>
                <a href="#contact" class="btn-get-started animate__animated animate__fadeInUp">Contact us</a>
              </div>
            </div>
      
            {/* <!-- Slide 2 --> */}
            {/* <!-- <div class="carousel-item">
              <div class="carousel-container">
                <h2 class="animate__animated animate__fadeInDown">YouTube</h2>
                <p class="animate__animated animate__fadeInUp">Global Income from Current YouTube Content</p>
                <a href="" class="btn-get-started animate__animated animate__fadeInUp">Read More</a>
              </div>
            </div> --> */}
      
            {/* <!-- Slide 3 --> */}
            <div class="carousel-item">
              <div class="carousel-container">
                <h2 class="animate__animated animate__fadeInDown">We Promote !</h2>
                <p class="animate__animated animate__fadeInUp">
                  <div class="features-new animate__animated animate__fadeInUp">
                    <ul>
                      <li><i class="bi bi-check"></i> Reach a whole new group of YouTube users by providing local
                        experiences in their own language,<br /> no matter where they are in
                        the world</li>
                  <li><i class="bi bi-check"></i> There are numerous ways to monetize your
                    content in the Global</li>
                  <li><i class="bi bi-check"></i> Examine the
                    possibilities</li></ul></div>
                  </p>
                <a href="#contact" class="btn-get-started animate__animated animate__fadeInUp">Contact us</a>
              </div>
            </div>
      
            <a class="carousel-control-prev" href="#heroCarousel" role="button" data-bs-slide="prev">
              <span class="carousel-control-prev-icon bx bx-chevron-left" aria-hidden="true"></span>
            </a>
      
            <a class="carousel-control-next" href="#heroCarousel" role="button" data-bs-slide="next">
              <span class="carousel-control-next-icon bx bx-chevron-right" aria-hidden="true"></span>
            </a>
      
          </div>
          {/* // <!-- End Hero --> */}
        </section>
      
    );
}

export default Hero;